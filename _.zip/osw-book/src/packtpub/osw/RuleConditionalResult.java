package packtpub.osw;

/**
 * Holder of rule result for conditions.
 */
public class RuleConditionalResult{
	private boolean result;

	/**
	 * @return the result
	 */
	public boolean getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(boolean result) {
		this.result = result;
	}

}