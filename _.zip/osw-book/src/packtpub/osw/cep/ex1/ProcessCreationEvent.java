/**
 * 
 */
package packtpub.osw.cep.ex1;

/**
 * @author Naya
 * @version 1.0
 */
public class ProcessCreationEvent {

}
