/**
 * 
 */
package packtpub.osw;

/**
 * @author Naya
 * @version 1.0
 */
public class UnpaidService {

}
