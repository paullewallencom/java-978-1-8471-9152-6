package packtpub.osw;

import java.util.Map;

import com.opensymphony.module.propertyset.PropertySet;
import com.opensymphony.workflow.FunctionProvider;
import com.opensymphony.workflow.WorkflowException;

public class TestFunction implements FunctionProvider {
	
	public void execute(Map transientVars, Map inputs, PropertySet ps)
			throws WorkflowException {
	}
}
